// hello.cpp : Defines the class behaviors for the application.
//

#include <iostream>
//  "t.t"
using namespace std;

int main ()
{
cout << "Hello World!";
return 0;
}

